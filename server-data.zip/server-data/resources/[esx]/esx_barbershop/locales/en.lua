Locales['en'] = {
  ['valid_purchase'] = 'validate this purchase?',
  ['yes'] = 'yes',
  ['no'] = 'no',
  ['not_enough_money'] = 'you do not have enough money',
  ['press_access'] = 'press ~INPUT_CONTEXT~ to access the menu',
  ['barber_blip'] = 'barber shop',
  ['you_paid'] = 'you paid $%s',
}
