Locales['es'] = {
  ['invoices'] = 'facturas',
  ['invoices_item'] = '€%s',
  ['received_invoice'] = 'has ~r~recibido~s~ una multa',
  ['paid_invoice'] = 'has ~g~pagado~s~ una multa de ~r~€%s~s~',
  ['received_payment'] = 'has ~g~recibido~s~ un pago de ~g~€%s~s~',
  ['player_not_online'] = 'el jugador no está conectado',
  ['no_money'] = 'you do not have enough money to pay this bill',
  ['target_no_money'] = 'the player ~r~does not~s~ have enough money to pay the bill!',
}
