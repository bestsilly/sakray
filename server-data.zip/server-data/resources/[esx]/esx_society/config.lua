Config = {}

Config.Locale = 'en'
Config.EnableESXIdentity = false
Config.MaxSalary = 3500
