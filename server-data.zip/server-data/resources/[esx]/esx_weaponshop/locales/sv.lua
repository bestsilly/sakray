Locales ['sv'] = {
  ['buy_license'] = 'vill du köpa ett vapenlicens?',
  ['yes'] = '%s',
  ['no'] = 'nej tack',
  ['weapon_bought'] = 'köpt för %s SEK',
  ['not_enough_black'] = 'du har inte tillräckligt med svarta pengar',
  ['not_enough'] = 'du har inte råd för detta',
  ['already_owned'] = 'du äger redan detta vapen!',
  ['shop_menu_title'] = 'vapenaffär',
  ['shop_menu_prompt'] = 'tryck ~INPUT_CONTEXT~ för att komma åt ~y~vapenaffären~s~.',
  ['shop_menu_item'] = '%s SEK',
  ['map_blip'] = 'vapenaffär',
}
