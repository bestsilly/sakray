Locales ['es'] = {
  ['buy_license'] = 'buy weapon license?',
  ['yes'] = '%s',
  ['no'] = 'no',
  ['weapon_bought'] = 'purchased for %s EUR',
  ['not_enough_black'] = 'usted no tiene ~r~suficiente~s~ dinero negro',
  ['not_enough'] = 'usted no tiene ~r~suficiente~s~ dinero',
  ['already_owned'] = 'you already own this weapon!',
  ['shop_menu_title'] = 'tienda',
  ['shop_menu_prompt'] = 'presione ~INPUT_CONTEXT~ para acceder a la tienda.',
  ['shop_menu_item'] = '%s EUR',
  ['map_blip'] = 'arsenal',
}
