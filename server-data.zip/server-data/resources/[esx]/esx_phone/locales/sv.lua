Locales['sv'] = {
  ['new_message'] = '~b~Nytt meddelande:~s~ %s',
  ['press_take_call'] = '%s - tryck ~INPUT_CONTEXT~ för att svara',
  ['taken_call'] = '~y~%s~s~ har tagit emot ditt meddelande',
  ['gps_position'] = 'destinationen är markerad på din GPS!',
  ['message_sent'] = 'meddelandet har skickats!',
  ['cannot_add_self'] = 'du kan inte lägga till dig själv!',
  ['number_in_contacts'] = 'det här nummret finns redan bland dina kontakter!',
  ['contact_added'] = 'kontakten har lags till!',
  ['contact_removed'] = 'kontakten har tagits bort!',
  ['number_not_assigned'] = 'det här nummret finns inte!',
  ['invalid_number'] = 'det är inte ett giltigt nummer!',
}
