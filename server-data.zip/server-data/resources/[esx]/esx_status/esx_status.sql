USE `sakray`;

ALTER TABLE `users` ADD COLUMN `status` LONGTEXT NULL;
