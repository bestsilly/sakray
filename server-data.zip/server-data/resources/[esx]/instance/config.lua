Config            = {}
Config.Locale     = 'fr'
Config.MaxPlayers = 32
